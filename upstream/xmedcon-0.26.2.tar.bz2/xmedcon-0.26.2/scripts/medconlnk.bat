@echo off

REM Helper batch file for CLI (X)MedCon

REM Get location
set XMEDCONBIN=%~dp0

REM Start in
cd "%USERPROFILE%"

REM Choose between powershell OR cmd
REM powershell.exe -NoExit "%XMEDCONBIN%medcon.exe"
REM    OR
cmd.exe /k "%XMEDCONBIN%medcon.exe"
